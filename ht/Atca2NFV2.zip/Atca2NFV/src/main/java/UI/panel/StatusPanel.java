package UI.panel;

import UI.AppMainWindow;
import UI.ConstantsUI;
import UI.GBC;
import UI.mycontainer.MyIconButton;
import logic.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tools.*;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * 状态面板
 *
 * @author Bob
 */
public class StatusPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerFactory.getLogger(StatusPanel.class);

    public static MyIconButton buttonStartSchedule;
    public static MyIconButton buttonStop;
    public static MyIconButton buttonStartNow;

    public static JProgressBar progressTotal;
    public static JProgressBar progressCurrent;

    public static JLabel labelStatus;
    public static JLabel labelStatusDetail;

    public JTextField taskName;
    public static JLabel labelFrom;
    public static JLabel labelTo;

    public static JTextField sourceTextField;
    public static JTextField targetTextField;

    public JButton sourceButton;
    public JButton targetButton;

    private JComboBox productCombox;
    private JComboBox sourceVersionCombox;
    private JComboBox targetVersionCombox;

    private DefaultComboBoxModel producModel=new DefaultComboBoxModel();
    private DefaultComboBoxModel sourceModel=new DefaultComboBoxModel();
    private DefaultComboBoxModel targetModel=new DefaultComboBoxModel();

    public JTextArea logArea;

    private String targetPath=ConstantsUI.CURRENT_DIR;

    private ConfigManager config = ConfigManager.getConfigManager();
    //总进度
    private JLabel labelTotal;

    public static boolean isRunning = false;

    /**
     * 构造
     */
    public StatusPanel() {
        super(true);
        initialize();
        addComponent();
        setContent();
        addListener();
    }

    /**
     * 初始化
     */
    private void initialize() {
        this.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
    }

    /**
     * 添加组件
     */
    private void addComponent() {
//        this.add(getUpPanel(),new GBC(0,0).setAnchor(GBC.WEST).setInsets(25));
//        this.add(getCenterPanel(),new GBC(0,1).setWeight(100,50).setInsets(10,25,0,0).setAnchor(GBC.WEST));

        JPanel topPanel=new JPanel();
        topPanel.setLayout(new GridBagLayout());
        topPanel.add(getUpPanel(),new GBC(0,1).setWeight(10,50).
                setAnchor(GBC.NORTHWEST).
                setFill(GBC.VERTICAL));

        topPanel.add(getCenterPanel(),new GBC(0,2).setWeight(0,50).
                setAnchor(GBC.NORTHWEST).
                setFill(GBC.VERTICAL));

        topPanel.add(getStartPanel(),new GBC(0,3).setWeight(0,10).
                setAnchor(GBC.EAST).setFill(GBC.HORIZONTAL));
        topPanel.setBackground(ConstantsUI.MAIN_BACK_COLOR);



        JSplitPane splitPane = new JSplitPane();

        splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(500);
        splitPane.setTopComponent(topPanel);
        splitPane.setBottomComponent(getDownPanel());


        this.add(splitPane);
    }

    /**
     * 上部面板
     *
     * @return
     */
    private JPanel getUpPanel() {
        JPanel panelUp = new JPanel();
        panelUp.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelUp.setLayout(new FlowLayout(FlowLayout.LEFT,25,5));

        JLabel labelTitle = new JLabel("ATCA2NFV");
        labelTitle.setFont(ConstantsUI.FONT_TITLE);
        labelTitle.setForeground(ConstantsUI.TOOL_BAR_BACK_COLOR);
        labelTitle.setPreferredSize(new Dimension(1300,30));

        labelStatus = new JLabel("当前状态");
        labelStatus.setPreferredSize(new Dimension(1300,30));
        labelStatusDetail = new JLabel("等待开始");
        labelStatusDetail.setPreferredSize(new Dimension(1500,30));
        labelStatus.setFont(ConstantsUI.FONT_NORMAL_BORD);
        labelStatusDetail.setFont(ConstantsUI.FONT_NORMAL);

        panelUp.add(labelTitle);
        panelUp.add(labelStatus);
        panelUp.add(labelStatusDetail);
        return panelUp;
    }

    /**
     * 中部面板
     *
     * @return
     */
    private JPanel getCenterPanel() {

        JPanel panelCenter = new JPanel();
        panelCenter.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelCenter.setLayout(new FlowLayout(FlowLayout.LEFT,0,5));

        JLabel taskLabel = new JLabel("局点名称");
        taskLabel.setFont(ConstantsUI.FONT_NORMAL);
        taskName = new JTextField();

        //产品、版本Grid
        JLabel productLabel = new JLabel("产品");
        productLabel.setFont(ConstantsUI.FONT_NORMAL);
        JLabel sourceVersionLable = new JLabel("源版本");
        sourceVersionLable.setFont(ConstantsUI.FONT_NORMAL);
        JLabel targetVersionLabel = new JLabel("目标版本");
        targetVersionLabel.setFont(ConstantsUI.FONT_NORMAL);

        //init ComBox
        for(String product:config.getAllProduct()){
            producModel.addElement(product);
        }
        productCombox = new JComboBox(producModel);
        productCombox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                sourceModel.removeAllElements();
                targetModel.removeAllElements();

                for(String sourceVersion:config.getSourceVersion(producModel.getSelectedItem().toString())){
                    sourceModel.addElement(sourceVersion);
                }

//                for(String targetVersion:config.getTargetVersion(producModel.getSelectedItem().toString(),
//                        sourceModel.getSelectedItem().toString())){
//                    targetModel.addElement(targetVersion);
//                }
            }
        });


        for(String sourceVersion:config.getSourceVersion(producModel.getSelectedItem().toString())){
            sourceModel.addElement(sourceVersion);
        }
        sourceVersionCombox = new JComboBox(sourceModel);
        sourceVersionCombox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if(sourceModel.getSize()==0){return;}
                targetModel.removeAllElements();
                for(String targetVersion:config.getTargetVersion(producModel.getSelectedItem().toString(),
                        sourceModel.getSelectedItem().toString())){
                    targetModel.addElement(targetVersion);
                }
            }
        });

        for(String targetVersion:config.getTargetVersion(producModel.getSelectedItem().toString(),
                sourceModel.getSelectedItem().toString())){
            targetModel.addElement(targetVersion);
        }
        targetVersionCombox = new JComboBox(targetModel);


        //源文件
        labelFrom = new JLabel("源文件");
        labelFrom.setFont(ConstantsUI.FONT_NORMAL);
        sourceTextField = new JTextField();
        sourceButton = new MyIconButton(ConstantsUI.ICON_OPEN,ConstantsUI.ICON_OPENENABLE,ConstantsUI.ICON_OPEN,"");

        //目标文件
        labelTo = new JLabel("结果保存路径");
        labelTo.setFont(ConstantsUI.FONT_NORMAL);
        targetTextField = new JTextField();
        targetButton = new MyIconButton(ConstantsUI.ICON_OPEN,ConstantsUI.ICON_OPENENABLE,ConstantsUI.ICON_OPEN,"");

        //布局

        JPanel rowPanel1 = new JPanel();
        rowPanel1.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        rowPanel1.setLayout(new FlowLayout(FlowLayout.LEFT,25,0));
        rowPanel1.setPreferredSize(new Dimension(1800,50));
        taskName.setPreferredSize(new Dimension(150,30));
        rowPanel1.add(taskLabel);
        rowPanel1.add(taskName);



        JPanel rowPanel2 = new JPanel(new FlowLayout(FlowLayout.LEFT,25,20));
        rowPanel2.setPreferredSize(new Dimension(1500,50));
        rowPanel2.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        rowPanel2.add(productLabel);
        rowPanel2.add(productCombox);
        rowPanel2.add(sourceVersionLable);
        rowPanel2.add(sourceVersionCombox);
        rowPanel2.add(targetVersionLabel);
        rowPanel2.add(targetVersionCombox);


        JPanel rowPanel3 = new JPanel(new GridLayout(2,1,25,0));
        rowPanel3.setPreferredSize(new Dimension(1500,80));
        rowPanel3.setBackground(ConstantsUI.MAIN_BACK_COLOR);

        JPanel soucePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 0));
        soucePanel.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        soucePanel.add(labelFrom);
        sourceTextField.setPreferredSize(new Dimension(300,30));
        soucePanel.add(sourceTextField);
        soucePanel.add(sourceButton);

        JPanel targetPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 0));
        targetPanel.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        targetPanel.add(labelTo);
        targetTextField.setPreferredSize(new Dimension(300,30));
        targetPanel.add(targetTextField);
        targetPanel.add(targetButton);


        rowPanel3.add(soucePanel);
        rowPanel3.add(targetPanel);

        panelCenter.add(rowPanel1);
        panelCenter.add(rowPanel2);
        panelCenter.add(rowPanel3);

//        panelCenter.add(taskLabel,new GBC(0,0).setAnchor(GBC.WEST));
//        panelCenter.add(taskName,new GBC(1,0,5,1).setFill(GBC.HORIZONTAL).setInsets(10));
//
//        panelCenter.add(productLabel,new GBC(0,1).setAnchor(GBC.WEST));
//        panelCenter.add(productCombox,new GBC(1,1).setInsets(10));
//        panelCenter.add(sourceVersionLable,new GBC(2,1));
//        panelCenter.add(sourceVersionCombox,new GBC(3,1).setInsets(10));
//        panelCenter.add(targetVersionLabel,new GBC(4,1));
//        panelCenter.add(targetVersionCombox,new GBC(5,1).setInsets(10));
//
//        panelCenter.add(labelFrom,new GBC(0,2).setAnchor(GBC.WEST));
//        panelCenter.add(sourceTextField,new GBC(1,2,5,1).setFill(GBC.HORIZONTAL).setInsets(10));
//        panelCenter.add(sourceButton,new GBC(12,2,1,1));
//
//        panelCenter.add(labelTo,new GBC(0,3));
//        panelCenter.add(targetTextField,new GBC(1,3,5,1).setFill(GBC.HORIZONTAL).setInsets(10));
//        panelCenter.add(targetButton,new GBC(12,3,1,1));

//        panelCenter.add(buttonStartNow,new GBC(0,4).setInsets(30).setAnchor(GBC.EAST));

        return panelCenter;
    }

    private JPanel getStartPanel(){
        JPanel panel=new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.X_AXIS));
        panel.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        //启动按钮
        buttonStartNow = new MyIconButton(ConstantsUI.ICON_SYNC_NOW, ConstantsUI.ICON_SYNC_NOW_ENABLE,
                ConstantsUI.ICON_SYNC_NOW_DISABLE, "");

        JButton button = new JButton("取消");
        panel.add(buttonStartNow);
        panel.add(button);
        return panel;
    }

    /**
     * 底部面板
     *
     * @return
     */
    private JPanel getDownPanel() {
        JPanel panelDown = new JPanel();
        panelDown.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelDown.setLayout(new BoxLayout(panelDown, BoxLayout.Y_AXIS));
        logArea = new JTextArea("转换日志...\n");
        logArea.setForeground(Color.BLACK);
        //启动自动换行
        logArea.setLineWrap(true);
        //换行不断字
        logArea.setWrapStyleWord(true);

        JScrollPane scrollBar = new JScrollPane(logArea);
        scrollBar.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        JPanel progressPanel = new JPanel();
        progressPanel.setLayout(new BoxLayout(progressPanel, BoxLayout.X_AXIS));
        labelTotal = new JLabel("转换进度");
        progressPanel.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        labelTotal.setFont(ConstantsUI.FONT_NORMAL);
        progressTotal = new JProgressBar();
        progressTotal.setStringPainted(true);
        progressPanel.add(labelTotal);
        progressPanel.add(progressTotal);

        scrollBar.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panelDown.add(progressPanel);
        panelDown.add(scrollBar);
        return panelDown;
    }

    /**
     * 设置状态面板组件内容
     */
    public static void setContent() {
//        String path = ConstantsUI.CURRENT_DIR;
//        targetTextField.setText(path);
    }

    /**
     * 为各组件添加事件监听
     */
    private void addListener() {
        buttonStartNow.addActionListener(e -> {
            if (isRunning == false) {

                String reg = "[\\u4e00-\\u9fa50-9A-Za-z]{1,50}";

                TaskModel task = new TaskModel();

                task.setTaskName(taskName.getText().trim());
                task.setProduct(productCombox.getSelectedItem().toString());
                task.setSouceVersion(sourceVersionCombox.getSelectedItem().toString());
                task.setTargetVersion(targetVersionCombox.getSelectedItem().toString());
                task.setSoucePath(sourceTextField.getText().trim());
                task.setTargetPath(targetTextField.getText());
                task.setCreatetime(Utils.getCurrentTime());
                task.setStatus("正常");

                ConfigManager config = ConfigManager.getConfigManager();
                try {
                    config.addLogElement(task);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }


//                if (!taskName.getText().matches(reg)){
//                    JOptionPane.showMessageDialog(null,
//                            "请确保局点名称不包含特殊字符，且小于50个字符。","错误",
//                            JOptionPane.ERROR_MESSAGE);
//                    return;
//                }

//                buttonStartNow.setEnabled(false);
//                labelTotal.setVisible(true);
//                progressTotal.setVisible(true);
//                StatusPanel.progressTotal.setValue(0);



//                labelStatus.setText(PropertyUtil.getProperty("ds.ui.status.manu"));
//                ExecuteThread syncThread = new ExecuteThread();
//                syncThread.run();


            }
        });

//        sourceButton.addActionListener(e ->{
//            JFileChooser chooser = new JFileChooser();
//            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
//            FileNameExtensionFilter filter = new FileNameExtensionFilter("TXT FILE","txt","TXT","Txt");
//            chooser.setFileFilter(filter);
//            int ret = chooser.showOpenDialog(this);
//            if (ret == JFileChooser.APPROVE_OPTION){
//                sourceTextField.setText(chooser.getSelectedFile().getPath());
//            }
//        });

//        targetButton.addActionListener(e ->{
//            JFileChooser chooser = new JFileChooser();
//            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
//            int ret = chooser.showOpenDialog(this);
//            if (ret == JFileChooser.APPROVE_OPTION){
//
//                targetPath = chooser.getSelectedFile().getPath();
//                targetTextField.setText(targetPath+ File.separator+taskName.getText().replace(" ",""));
//            }
//        });

//        taskName.getDocument().addDocumentListener(new DocumentListener() {
//            @Override
//            public void insertUpdate(DocumentEvent e) {
//                targetTextField.setText(targetPath+ File.separator+taskName.getText().replace(" ",""));
//            }
//
//            @Override
//            public void removeUpdate(DocumentEvent e) {
//                targetTextField.setText(targetPath+ File.separator+taskName.getText().replace(" ",""));
//            }
//
//            @Override
//            public void changedUpdate(DocumentEvent e) {
//                targetTextField.setText(targetPath+ File.separator+taskName.getText());
//            }
//        });
    }
}

