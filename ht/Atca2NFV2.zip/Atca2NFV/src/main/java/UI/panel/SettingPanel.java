package UI.panel;

import UI.AppMainWindow;
import UI.ConstantsUI;
import tools.PropertyUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * 设置面板
 *
 * @author Bob
 */
public class SettingPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    private static JPanel panelOption;
    private static JPanel panelAbout;
    public static JPanel settingPanelMain;
    private static JPanel settingPanelAbout;

    /**
     * 构造
     */
    public SettingPanel() {
        initialize();
        addComponent();
        addListener();
    }

    /**
     * 初始化
     */
    private void initialize() {
        this.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        this.setLayout(new BorderLayout());
        settingPanelAbout = new SettingPanelAbout();
    }

    /**
     * 添加组件
     */
    private void addComponent() {

        this.add(getCenterPanel(), BorderLayout.CENTER);

    }



    /**
     * 中部面板
     *
     * @return
     */
    private JPanel getCenterPanel() {

        Dimension preferredSizeListItem = new Dimension(245, 48);
        panelAbout = new JPanel();
        panelAbout.setBackground(ConstantsUI.TOOL_BAR_BACK_COLOR);
        panelAbout.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 13));
        panelAbout.setPreferredSize(preferredSizeListItem);

        JLabel labelAbout = new JLabel(PropertyUtil.getProperty("ds.ui.setting.about"));
        Font fontListItem = new Font(PropertyUtil.getProperty("ds.ui.font.family"), 0, 15);
        labelAbout.setFont(fontListItem);
        labelAbout.setForeground(Color.white);
        panelAbout.add(labelAbout);


        // 设置Panel
        settingPanelMain = new JPanel();
        settingPanelMain.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        settingPanelMain.setLayout(new BorderLayout());

        return panelAbout;
    }

    /**
     * 为相关组件添加事件监听
     */
    private void addListener() {
        panelAbout.addMouseListener(new MouseListener() {

            @Override
            public void mouseReleased(MouseEvent e) {
                // TODO Auto-generated method stub

            }

            @Override
            public void mousePressed(MouseEvent e) {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseExited(MouseEvent e) {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseClicked(MouseEvent e) {
                panelAbout.setBackground(new Color(69, 186, 121));
                SettingPanel.settingPanelMain.removeAll();
                SettingPanel.settingPanelMain.add(settingPanelAbout);
                AppMainWindow.settingPanel.updateUI();
            }
        });

    }
}