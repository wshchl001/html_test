package UI.panel;

import UI.AppMainWindow;
import UI.ConstantsUI;
import UI.mycontainer.MyIconButton;
import logic.ConstantsLogic;
import logic.TaskModel;
import org.dom4j.DocumentException;
import tools.ConfigManager;
import tools.FileUtils;
import tools.PropertyUtil;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.Map;

/**
 * 备份面板
 *
 * @author Bob
 */
public class BackupPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    public static JTable tableFrom;

    private static MyIconButton buttonNewBakFrom;

    private static MyIconButton buttonDelBakFrom;

    private static Object[][] tableDatas;

    private static DefaultTableModel model;

    /**
     * 构造
     */
    public BackupPanel() {
        initialize();
        initTableData();
        addComponent();

        addListener();
    }

    /**
     * 初始化面板
     */
    private void initialize() {
        this.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        this.setLayout(new BorderLayout());
    }

    /**
     * 为面板添加组件
     */
    private void addComponent() {

        this.add(getUpPanel(), BorderLayout.NORTH);
        this.add(getCenterPanel(), BorderLayout.CENTER);
    }

    /**
     * 面板上部
     *
     * @return
     */
    private JPanel getUpPanel() {
        JPanel panelUp = new JPanel();
        panelUp.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelUp.setLayout(new FlowLayout(FlowLayout.LEFT, ConstantsUI.MAIN_H_GAP, 5));

        JLabel labelTitle = new JLabel(PropertyUtil.getProperty("ds.ui.backup.title"));
        labelTitle.setFont(ConstantsUI.FONT_TITLE);
        labelTitle.setForeground(ConstantsUI.TOOL_BAR_BACK_COLOR);
        panelUp.add(labelTitle);

        return panelUp;
    }

    /**
     * 面板中部
     *
     * @return
     */
    private JPanel getCenterPanel() {
        // 中间面板
        JPanel panelCenter = new JPanel();
        panelCenter.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelCenter.setLayout(new GridLayout(1, 1));

        panelCenter.add(getPanelGridBakFrom());

        return panelCenter;
    }

    /**
     * 数据库来源Grid面板
     *
     * @return
     */
    private JPanel getPanelGridBakFrom() {
        // 来源备份Grid
        JPanel panelGridBakFrom = new JPanel();
        panelGridBakFrom.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelGridBakFrom.setLayout(new BorderLayout());

        JPanel panelFromControl = new JPanel();
        panelFromControl.setLayout(new GridLayout(1, 2));
        JPanel panelFromTable = new JPanel();
        panelFromTable.setLayout(new BorderLayout());

        // 初始化控制组件
        JPanel panelFromControlLeft = new JPanel();
        panelFromControlLeft.setLayout(new FlowLayout(FlowLayout.LEFT, ConstantsUI.MAIN_H_GAP, 5));
        panelFromControlLeft.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        JPanel panelFromControlRight = new JPanel();
        panelFromControlRight.setLayout(new FlowLayout(FlowLayout.RIGHT, ConstantsUI.MAIN_H_GAP, 5));
        panelFromControlRight.setBackground(ConstantsUI.MAIN_BACK_COLOR);

        JLabel labelFrom = new JLabel(PropertyUtil.getProperty("ds.ui.database.label.to"));
        labelFrom.setFont(new Font(PropertyUtil.getProperty("ds.ui.font.family"), 0, 18));
        labelFrom.setForeground(Color.gray);
        panelFromControlLeft.add(labelFrom);

        buttonNewBakFrom = new MyIconButton(ConstantsUI.ICON_NEW_BAK, ConstantsUI.ICON_NEW_BAK_ENABLE,
                ConstantsUI.ICON_NEW_BAK_DISABLE, "");
        MyIconButton buttonRecvBakFrom = new MyIconButton(ConstantsUI.ICON_RECOVER_BAK,
                ConstantsUI.ICON_RECOVER_BAK_ENABLE, ConstantsUI.ICON_RECOVER_BAK_DISABLE, "");
         buttonDelBakFrom = new MyIconButton(ConstantsUI.ICON_DEL_BAK, ConstantsUI.ICON_DEL_BAK_ENABLE,
                ConstantsUI.ICON_DEL_BAK_DISABLE, "");
        panelFromControlRight.add(buttonNewBakFrom);
        panelFromControlRight.add(buttonRecvBakFrom);
        panelFromControlRight.add(buttonDelBakFrom);

        panelFromControl.add(panelFromControlLeft);
        panelFromControl.add(panelFromControlRight);

        panelGridBakFrom.add(panelFromControl, BorderLayout.NORTH);

        // 初始化表格组件

        tableFrom = new JTable(model);
        tableFrom.setFont(ConstantsUI.FONT_NORMAL);
        tableFrom.getTableHeader().setFont(ConstantsUI.FONT_NORMAL);
        tableFrom.getTableHeader().setBackground(ConstantsUI.TOOL_BAR_BACK_COLOR);
        tableFrom.setRowHeight(31);
        tableFrom.setGridColor(ConstantsUI.TABLE_LINE_COLOR);
        tableFrom.setSelectionBackground(ConstantsUI.TOOL_BAR_BACK_COLOR);
        // 设置列宽
        tableFrom.getColumnModel().getColumn(0).setPreferredWidth(10);
        tableFrom.getColumnModel().getColumn(0).setMaxWidth(10);
        tableFrom.getColumnModel().getColumn(1).setPreferredWidth(150);
        tableFrom.getColumnModel().getColumn(1).setMaxWidth(150);
        tableFrom.getColumnModel().getColumn(2).setPreferredWidth(150);
        tableFrom.getColumnModel().getColumn(2).setMaxWidth(150);
        tableFrom.getColumnModel().getColumn(3).setPreferredWidth(150);
        tableFrom.getColumnModel().getColumn(3).setMaxWidth(150);

        JScrollPane panelScroll = new JScrollPane(tableFrom);
        panelScroll.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelGridBakFrom.add(panelScroll, BorderLayout.CENTER);

        return panelGridBakFrom;
    }

    public static void initTableData() {
        ConfigManager configManager = ConfigManager.getConfigManager();
        try {
            Map<String, TaskModel> map = configManager.getAllTask();
            tableDatas = new Object[map.size()][3];
            int i = 0;
            for (Map.Entry<String, TaskModel> entry : map.entrySet()) {
                TaskModel task = entry.getValue();
                tableDatas[i] = new Object[]{i + 1, task.getSoucePath(), task.getTaskName(), task.getProduct()};
                i++;
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        String[] colums = new String[]{"编号", "源文件", "局点名", "产品名"};
        model = new DefaultTableModel(tableDatas, colums);

        if (tableFrom != null) {
            tableFrom.setModel(model);
        }

    }

    private void addListener() {
        buttonNewBakFrom.addActionListener(e -> AppMainWindow.dialog.setVisible(true));
        buttonDelBakFrom.addActionListener(e -> {
            ConfigManager config = ConfigManager.getConfigManager();
            try {


                config.removeAllTask();
                initTableData();
//                AppMainWindow.mainPanelCenter.removeAll();
//                AppMainWindow.mainPanelCenter.add(AppMainWindow.backupPanel, BorderLayout.CENTER);
//
//                AppMainWindow.mainPanelCenter.updateUI();
               JOptionPane.showMessageDialog(null,"删除陈公公","信息",JOptionPane.INFORMATION_MESSAGE);

//                AbstractTableModel model = (AbstractTableModel) tableFrom.getModel();
//                model.fireTableDataChanged();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }

}