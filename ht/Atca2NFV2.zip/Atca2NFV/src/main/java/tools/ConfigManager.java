package tools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.*;

import logic.TaskModel;
import org.dom4j.*;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 配置文件管理 单例
 *
 * @author Bob
 */
public class ConfigManager {
    private volatile static ConfigManager confManager;
    private static final Logger logger = LoggerFactory.getLogger(ConfigManager.class);
    public Document document;

    /**
     * 私有的构造
     */
    private ConfigManager() {
        reloadDom();
    }

    /**
     * 读取xml，加载到dom
     */
    public void reloadDom() {
        SAXReader reader = new SAXReader();
        try {
            document = reader.read(new File(ConstantsTools.PATH_CONFIG));
        } catch (DocumentException e) {
            e.printStackTrace();
            logger.error("Read config xml error:" + e.toString());
        }
    }

    /**
     * 获取实例，线程安全
     *
     * @return
     */
    public static ConfigManager getConfigManager() {
        if (confManager == null) {
            synchronized (ConfigManager.class) {
                if (confManager == null) {
                    confManager = new ConfigManager();
                }
            }
        }
        return confManager;
    }

    /**
     * 把document对象写入新的文件
     *
     * @throws Exception
     */
    public void writeToXml() throws Exception {
        // 排版缩进的格式
        OutputFormat format = OutputFormat.createPrettyPrint();
        // 设置编码
        format.setEncoding("UTF-8");
        // 创建XMLWriter对象,指定了写出文件及编码格式
        XMLWriter writer = null;
        writer = new XMLWriter(
                new OutputStreamWriter(new FileOutputStream(new File(ConstantsTools.PATH_CONFIG)), "UTF-8"), format);

        // 写入
        writer.write(document);
        writer.flush();
        writer.close();

    }

    public String getLastSyncTime() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_LAST_SYNC_TIME).getText();
    }

    public void setLastSyncTime(String lastSyncTime) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_LAST_SYNC_TIME).setText(lastSyncTime);

        writeToXml();
    }

    public String getLastKeepTime() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_LAST_KEEP_TIME).getText();
    }

    public void setLastKeepTime(String lastKeepTime) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_LAST_KEEP_TIME).setText(lastKeepTime);
        writeToXml();
    }

    public String getSuccessTime() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_SUCCESS_TIME).getText();
    }

    public void setSuccessTime(String successTime) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_SUCCESS_TIME).setText(successTime);
        writeToXml();
    }

    public String getFailTime() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_FAIL_TIME).getText();
    }

    public void setFailTime(String failTime) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_FAIL_TIME).setText(failTime);
        writeToXml();
    }

    public String getTypeFrom() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_TYPE_FROM).getText();
    }

    public void setTypeFrom(String typeFrom) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_TYPE_FROM).setText(typeFrom);
        writeToXml();
    }

    public String getHostFrom() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_HOST_FROM).getText();
    }

    public void setHostFrom(String hostFrom) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_HOST_FROM).setText(hostFrom);
        writeToXml();
    }

    public String getNameFrom() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_NAME_FROM).getText();
    }

    public void setNameFrom(String nameFrom) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_NAME_FROM).setText(nameFrom);
        writeToXml();
    }

    public String getUserFrom() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_USER_FROM).getText();
    }

    public void setUserFrom(String userFrom) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_USER_FROM).setText(userFrom);
        writeToXml();
    }

    public String getPasswordFrom() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_PASSWORD_FROM).getText();
    }

    public void setPasswordFrom(String passwordFrom) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_PASSWORD_FROM).setText(passwordFrom);
        writeToXml();
    }

    public String getTypeTo() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_TYPE_TO).getText();
    }

    public void setTypeTo(String typeTo) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_TYPE_TO).setText(typeTo);
        writeToXml();
    }

    public String getHostTo() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_HOST_TO).getText();
    }

    public void setHostTo(String hostTo) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_HOST_TO).setText(hostTo);
        writeToXml();
    }

    public String getNameTo() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_NAME_TO).getText();
    }

    public void setNameTo(String nameTo) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_NAME_TO).setText(nameTo);
        writeToXml();
    }

    public String getUserTo() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_USER_TO).getText();
    }

    public void setUserTo(String userTo) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_USER_TO).setText(userTo);
        writeToXml();
    }

    public String getPasswordTo() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_PASSWORD_TO).getText();
    }

    public void setPasswordTo(String passwordTo) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_PASSWORD_TO).setText(passwordTo);
        writeToXml();
    }

    public String getSchedule() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_SCHEDULE).getText();
    }

    public void setSchedule(String schedule) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_SCHEDULE).setText(schedule);

        writeToXml();
    }

    public String getScheduleFixTime() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_SCHEDULE_FIX_TIME).getText();
    }

    public void setScheduleFixTime(String fixTime) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_SCHEDULE_FIX_TIME).setText(fixTime);
        writeToXml();
    }

    public String getAutoBak() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_AUTO_BAK).getText();
    }

    public void setAutoBak(String autoBak) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_AUTO_BAK).setText(autoBak);
        writeToXml();
    }

    public String getDebugMode() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_DEBUG_MODE).getText();
    }

    public void setDebugMode(String debugMode) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_DEBUG_MODE).setText(debugMode);
        writeToXml();
    }

    public String getStrictMode() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_STRICT_MODE).getText();
    }

    public void setStrictMode(String strictMode) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_STRICT_MODE).setText(strictMode);
        writeToXml();
    }

    public String getMysqlPath() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_MYSQL_PATH).getText();
    }

    public void setMysqlPath(String mysqlPath) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_MYSQL_PATH).setText(mysqlPath);
        writeToXml();
    }

    public String getProductName() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_PRODUCT_NAME).getText();
    }

    public void setProductName(String productName) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_PRODUCT_NAME).setText(productName);
        writeToXml();
    }

    public String getPositionCode() {
        return this.document.selectSingleNode(ConstantsTools.XPATH_POSITION_CODE).getText();
    }

    public void setPositionCode(String positionCode) throws Exception {
        this.document.selectSingleNode(ConstantsTools.XPATH_POSITION_CODE).setText(positionCode);
        writeToXml();
    }

    private void setTaskName(TaskModel task,String nodeName,String nodeTxt){
        switch (nodeName) {
            case "taskName":
                task.setTaskName(nodeTxt);
                break;
            case "product":
                task.setProduct(nodeTxt);
                break;
            case "souceVersion":
                task.setSouceVersion(nodeTxt);
                break;
            case "targetVersion":
                task.setTargetVersion(nodeTxt);
                break;
            case "soucePath":
                task.setSoucePath(nodeTxt);
                break;
            case "targetPath":
                task.setTargetPath(nodeTxt);
                break;
            case "createtime":
                task.setCreatetime(nodeTxt);
                break;
            case "status":
                task.setStatus(nodeTxt);
                break;
            default:
                break;
        }
    }

    public Map<String, TaskModel> getAllTask() throws DocumentException {
        Map<String, TaskModel> map = new HashMap<String, TaskModel>();
        TaskModel task;
        int taskNum = 1;
        List<Element> element = this.document.getRootElement().element("convertLog").elements("log");
        Iterator iter = element.iterator();
        while (iter.hasNext()) {
            Element logs = (Element) iter.next();
            Iterator iter2 = logs.elementIterator();
            task = new TaskModel();
            while (iter2.hasNext()) {
                Node log = (Element) iter2.next();
                setTaskName(task,log.getName(),log.getText());
            }
            map.put(String.valueOf(taskNum), task);
            taskNum++;
        }

        return map;
    }

    public void removeAllTask() throws Exception {

        String xpath = "/weSync/convertLog";

        List lst = this.document.selectNodes(xpath);
        Iterator iter = lst.iterator();
        while (iter.hasNext()) {
            Element element = (Element) iter.next();
            Iterator iter2 = element.elementIterator();
            while (iter2.hasNext()) {
                Element element1 = (Element) iter2.next();
                element.remove(element1);
            }
        }
        this.writeToXml();
    }

    public void addLogElement(TaskModel task) throws Exception{
        Element logs = this.document.getRootElement().element("convertLog");
        Element logNode = logs.addElement("log");
        Element nodetaskName = logNode.addElement("taskName");
        Element nodeproduct = logNode.addElement("product");
        Element nodesouceVersion = logNode.addElement("souceVersion");
        Element nodetargetVersion = logNode.addElement("targetVersion");
        Element nodesoucePath = logNode.addElement("soucePath");
        Element nodetargetPath = logNode.addElement("targetPath");
        Element nodecreatetime = logNode.addElement("createtime");
        Element nodestatus = logNode.addElement("status");

        nodetaskName.setText(task.getTaskName());
        nodeproduct.setText(task.getProduct());
        nodesouceVersion.setText(task.getSouceVersion());
        nodetargetVersion.setText(task.getTargetVersion());
        nodesoucePath.setText(task.getSoucePath());
        nodetargetPath.setText(task.getTargetPath());
        nodecreatetime.setText(task.getCreatetime());
        nodestatus.setText(task.getStatus());

        this.writeToXml();
    }

    public List<String> getAllProduct(){
        List<String> list = new ArrayList<>();

        List<Element> converts = this.document.getRootElement().elements("convertVsion");
        for(Element convert:converts){
            Iterator it = convert.elementIterator();
            while (it.hasNext()){
                Element element=(Element) it.next();
                Attribute attr = element.attribute("product");
                if (!list.contains(attr.getValue())){
                    list.add(attr.getValue());
                }
            }
        }
        return list;
    }

    public List<String> getSourceVersion(String product){
        List<String> list = new ArrayList<>();

        List<Element> converts = this.document.getRootElement().elements("convertVsion");
        for(Element convert:converts){
            Iterator it = convert.elementIterator();
            while (it.hasNext()){
                Element element=(Element) it.next();
                Attribute attrProduct = element.attribute("product");
                if (!attrProduct.getValue().equals(product)){
                    continue;
                }
                Attribute attrSourceVersion = element.attribute("souceVersion");
                if (!list.contains(attrSourceVersion.getValue())){
                    list.add(attrSourceVersion.getValue());
                }
            }
        }
        return list;
    }

    public List<String> getTargetVersion(String product,String souceVersion){
        List<String> list = new ArrayList<>();

        List<Element> converts = this.document.getRootElement().elements("convertVsion");
        for(Element convert:converts){
            Iterator it = convert.elementIterator();
            while (it.hasNext()){
                Element element=(Element) it.next();
                Attribute attrProduct = element.attribute("product");
                if (!attrProduct.getValue().equals(product) ){
                    continue;
                }
                Attribute attrSouceVersion = element.attribute("souceVersion");
                if (!attrSouceVersion.getValue().equals(souceVersion) ){
                    continue;
                }

                if (!list.contains(element.getTextTrim())){
                    list.add(element.getTextTrim());
                }
            }
        }
        return list;
    }
}
