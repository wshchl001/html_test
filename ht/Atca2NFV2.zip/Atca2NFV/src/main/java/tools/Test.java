package tools;

import UI.AppMainWindow;
import UI.GBC;
import javafx.concurrent.Task;
import logic.TaskModel;
import org.dom4j.*;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.text.html.HTMLDocument;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.util.*;
import java.util.List;


public class Test extends JFrame {

    private static Logger logger = LoggerFactory.getLogger(Test.class);

    /**
     * 遍历当前节点元素下面的所有(元素的)子节点
     * <p>
     * //     * @param node
     */
//    public static void arrayNodes(Map<String, Object> nodeMap, Element node, Element root) {
//        System.out.println("----------------------------");
//        // 当前节点的名称、文本内容和属性
//        System.out.println("当前节点名称：" + node.getName());// 当前节点名称
//        if (!(node.getTextTrim().equals(""))) {
//            System.out.println("当前节点的内容：" + node.getTextTrim());// 当前节点名称
//        }
//        String nodeName = node.getName();
//        String nodeValue = node.getTextTrim();
//        nodeMap.put(nodeName, nodeValue);
//        // 当前节点下面子节点迭代器
//        @SuppressWarnings("unchecked")
//        Iterator<Element> it = node.elementIterator();
//        // 遍历
//        while (it.hasNext()) {
//            // 获取某个子节点对象
//            Element e = it.next();
//            // 对子节点进行遍历
//            arrayNodes(nodeMap, e, root);
//        }
//    }
//
//
//    /**
//     * @方法功能描述: 解析XML，并将节点为KEY,值为VALUE，存入Map<String,Object>
//     * @方法返回类型:Map<String,Object>
//     * @param xmlText
//     * @param xPath
//     * @return
//     */
//    @SuppressWarnings("unchecked")
//    public static Map<String, Object> getAppointedElementTextMap(String xmlPath, String xPath)
//    throws DocumentException
//    {
//        Map<String, Object> elementMap = new HashMap<String, Object>();
//        // 定义list
//        List<Element> elements = new ArrayList<Element>();
//        // 获取document对象
//        Document document = new SAXReader().read(xmlPath);
//        // 获取根节点
//        Element rooElement = document.getRootElement();
//        if (Objects.isNull(xPath)) {
//            elements.add(rooElement);
//
//        } else {
//            elements = (List<Element>) rooElement.selectNodes(xPath);
//            if (elements != null) {
//                for (Element element : elements) {
//                    arrayNodes(elementMap, element, rooElement);
//                }
//            }
//            if (elements.size() == 0) {
//                logger.error("xPath（DOM树路径）出现错误！");
//            }
//        }
//        return elementMap;
//    }
    public Test() {

        try {

//            ConfigManager configManager = ConfigManager.getConfigManager();
//
//            configManager.removeAllTask();

            Document document = new SAXReader().read(ConstantsTools.PATH_CONFIG);
            String xpath = "/weSync/convertLog/log";

            List<Element> convets = document.getRootElement().elements("convertVsion");

            for(Element convert:convets){
                Iterator it = convert.elementIterator();
                while (it.hasNext()){
                    Element element=(Element) it.next();
                    Attribute att = element.attribute("product");
                    System.out.println(att.getValue());
                }
            }




//            XMLWriter xmlWriter = new XMLWriter(new FileOutputStream(ConstantsTools.PATH_CONFIG),
//                    OutputFormat.createPrettyPrint());
//
//            xmlWriter.write(document);
//            xmlWriter.close();





            //
//
//
//            List lst = document.selectNodes(xpath);
//            Iterator iter = lst.iterator();
//            while (iter.hasNext()){
//                Element element = (Element) iter.next();
//                Iterator iter2 = element.elementIterator();
//                while (iter2.hasNext()) {
//                    Element element1 = (Element) iter2.next();
//                    element.remove(element1);
//                }
//            }


//            while (iter.hasNext()) {
//                Element element = (Element) iter.next();
//                Iterator iter2 = element.elementIterator();
//                while (iter2.hasNext()) {
//                    Element element2 = (Element) iter2.next();
//                    Iterator iter3 = element2.elementIterator();
//                    while (iter3.hasNext()) {
//                        Element element3 = (Element) iter3.next();
//                        switch (element3.getName()){
//                            case "taskName":
//                                System.out.println(element3.getStringValue());
//                                break;
//                            default:break;
//                        }
//                    }
//                }
//
//
//            }


//            Element rootElement = (Element) document.getRootElement();
//            Element log = (Element) document.getRootElement().selectSingleNode(xpath);

//            System.out.println(log.elementText("TaskName"));

//            Iterator it = log.iterator();
//
//            while (it.hasNext()){
//                Element element = (Element) it.next();
//                Attribute attribute = element.attribute("taskName");
//                System.out.println(attribute.getName());
//            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        List<String> list = new ArrayList<>();
        for (String s:new String[]{"aaa","bbb","aaa","ddd"})
        {
            if (!list.contains(s))
            {
                list.add(s);
            }
        }

        for(String s:list)
        {
            System.out.println(s);
        }

//        Test test = new Test();
    }
}
