package tools;

import UI.AppMainWindow;

import java.io.*;
import java.util.Properties;

/**
 * Created by zhouy on 2017/2/27.
 */
public class PropertyUtil {

    /**
     * 获取property
     *
     * @param key
     * @return
     */
    public static String getProperty(String key) {
        Properties pps = new Properties();
        try {
            FileInputStream fs = new FileInputStream(ConstantsTools.PATH_PROPERTY);
            InputStreamReader in = new InputStreamReader(fs,"UTF-8");
            pps.load(in);
            String value = pps.getProperty(key);
            return value;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
