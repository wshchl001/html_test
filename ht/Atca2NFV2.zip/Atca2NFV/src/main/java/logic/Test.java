package logic;
import logic.LocalCommandExecutorService;
import org.dom4j.DocumentException;
import tools.ConfigManager;

import java.util.HashMap;
import java.util.Map;

public class Test {
    public static void main(String[] args) {

        ConfigManager config = ConfigManager.getConfigManager();
        try {
            Map<String,TaskModel> map = config.getAllTask();
            for(Map.Entry<String,TaskModel> entry:map.entrySet()){
                System.out.println(entry.getKey()+":"+entry.getValue().getTaskName());
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }
}