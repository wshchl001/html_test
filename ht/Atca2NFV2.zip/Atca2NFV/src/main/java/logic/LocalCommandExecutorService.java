package logic;

public interface LocalCommandExecutorService {
    ExecuteResult executeCommand(String[] command, long timeout);
}