package logic;

public class TaskModel {

    private String logNum;
    private String taskName;
    private String product;
    private String souceVersion;
    private String targetVersion;
    private String soucePath;
    private String targetPath;
    private String createtime;
    private String status;


    public String getLogNum() {
        return logNum;
    }

    public void setLogNum(String logNum) {
        this.logNum = logNum;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSouceVersion() {
        return souceVersion;
    }

    public void setSouceVersion(String souceVersion) {
        this.souceVersion = souceVersion;
    }

    public String getTargetVersion() {
        return targetVersion;
    }

    public void setTargetVersion(String targetVersion) {
        this.targetVersion = targetVersion;
    }

    public String getSoucePath() {
        return soucePath;
    }

    public void setSoucePath(String soucePath) {
        this.soucePath = soucePath;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
