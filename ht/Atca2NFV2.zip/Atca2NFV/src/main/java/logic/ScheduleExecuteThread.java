package logic;

import UI.panel.StatusPanel;
import tools.*;

/**
 * 定时任务执行器，继承于执行器线程类
 *
 * @author Bob
 */
public class ScheduleExecuteThread extends ExecuteThread {

    @Override
    public void run() {
            // 设置显示下一次执行时间
            StatusPanel.isRunning = false;
        }
    }

