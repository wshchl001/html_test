package logic;

import UI.AppMainWindow;
import UI.panel.StatusPanel;
import jdk.nashorn.internal.parser.JSONParser;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tools.Utils;

import javax.swing.*;
import java.io.FileReader;

public class ProgressThread extends Thread {
    private Logger logger = LoggerFactory.getLogger(AppMainWindow.class);

    @Override
    public void run(){
        this.setName("ProgressThread");
        JProgressBar progressBar = StatusPanel.progressTotal;
        while (progressBar.getValue() != 100) {
            try {
                JSONObject jsonTask =new JSONObject(Utils.readFile("C:\\Users\\Administrator\\Desktop\\task.json"));
                JSONObject task = jsonTask.getJSONObject("default");
                int progress = task.getInt("progress");
                if (progress> progressBar.getValue()){
                    progressBar.setValue(progress);
                }
                Thread.sleep(1000);
            } catch (Exception e) {
//               logger.error(Utils.getStackMsg(e));
                e.printStackTrace();
            }

        }
    }
}
