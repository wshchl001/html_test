package logic;

import UI.panel.StatusPanel;
import netscape.javascript.JSObject;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tools.Utils;

import javax.swing.*;
import java.io.*;

/**
 * 执行器线程
 *
 * @author Alon
 */
public class ExecuteThread extends Thread{

    private static final Logger logger = LoggerFactory.getLogger(ExecuteThread.class);
    private RealtimeProcess mRealtimeProcess = null;

    /**
     * 初始化变量
     */
    public void init() {

    }

    @Override
    public void run() {
        StatusPanel.isRunning = true;

        LocalCommandExecutorService service = new LocalCommandExecutorServiceImpl();
        String[] command = new String[]{"python","C:\\Users\\Administrator\\Desktop\\nfv.py"};
        ExecuteResult result = service.executeCommand(command, 5000);
        logger.info("退出码："+result.getExitCode());
        logger.info("输出内容："+result.getExecuteOut());
//        String exe = "python";
//        String command = "C:\\Users\\Administrator\\Desktop\\nfv.py";
//        String num1 = StatusPanel.targetTextField.getText();
//        String[] cmdArr = new String[]{exe, command, num1};
//        logger.info(exe + " " + command + " " + num1);
//        JProgressBar progressBar = StatusPanel.progressTotal;
//        Process process = null;
//        InputStream in = null;
//        try {
//            int rs = 0;
//            progressBar.setValue(0);
//            ProgressThread progressThread = new ProgressThread();
//            progressThread.start();
//            ProcessBuilder builder = new ProcessBuilder("python", "C:\\Users\\Administrator\\Desktop\\nfv.py");
//            builder.redirectErrorStream(false);
//            process = builder.start();
//            in = process.getInputStream();
//            BufferedReader br = new BufferedReader(new InputStreamReader(in));
//            String output = null;
//
//            while (null != (output = br.readLine())) {
//                logger.info(output);
//            }
//            rs = process.waitFor();
//            logger.info(String.valueOf(rs));
//
//
//            progressBar.setValue(100);
//            JOptionPane.showMessageDialog(null, "转换完成", "信息", JOptionPane.INFORMATION_MESSAGE);
//        } catch (Exception e) {
//            progressBar.setValue(0);
//            JOptionPane.showMessageDialog(null, "转换失败", "信息", JOptionPane.ERROR_MESSAGE);
//            logger.error(Utils.getStackMsg(e));
//        } finally {
//            StatusPanel.buttonStartNow.setEnabled(true);
//            StatusPanel.isRunning = false;
//            try {
//                in.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
    }}

