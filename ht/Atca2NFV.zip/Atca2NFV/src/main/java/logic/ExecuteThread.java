package logic;

import UI.panel.StatusPanel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.io.*;

/**
 * 执行器线程
 *
 * @author Alon
 */
public class ExecuteThread extends Thread{

    private static final Logger logger = LoggerFactory.getLogger(ExecuteThread.class);

    /**
     * 初始化变量
     */
    public void init() {

    }

    @Override
    public void run() {
        StatusPanel.isRunning = true;
        this.setName("ExecuteThread");

        ;

        String exe = "python";
        String command = "C:\\Users\\Administrator\\Desktop\\atca.py";
        String num1 = StatusPanel.targetTextField.getText();
        String[] cmdArr = new String[] {exe,command,num1};
        logger.info(exe+" "+command+" "+num1);
        JProgressBar progressBar = StatusPanel.progressTotal;
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(cmdArr);
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            progressBar.setValue(10);
            while ((line = in.readLine()) != null) {
                logger.info(line);
                progressBar.setValue(progressBar.getValue()+1);
            }

            in.close();
            process.waitFor();
            progressBar.setValue(100);

        } catch (Exception e) {

            logger.error(e.getStackTrace().toString());
        }
        JOptionPane.showMessageDialog(null,"转换完成","信息",JOptionPane.INFORMATION_MESSAGE);
        StatusPanel.buttonStartNow.setEnabled(true);
        StatusPanel.isRunning = false;
    }
}
