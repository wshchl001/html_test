package tools;

/**
 * 日志级别枚举
 *
 * @author Bob
 */
public enum LogLevel {

    INFO, DEBUG, WARN, ERROR, FATAL
}
