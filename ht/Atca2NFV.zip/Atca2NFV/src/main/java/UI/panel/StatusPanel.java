package UI.panel;

import UI.AppMainWindow;
import UI.ConstantsUI;
import UI.GBC;
import UI.mycontainer.MyIconButton;
import logic.ExecuteThread;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tools.FileUtils;
import tools.PropertyUtil;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

/**
 * 状态面板
 *
 * @author Bob
 */
public class StatusPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerFactory.getLogger(StatusPanel.class);

    public static MyIconButton buttonStartSchedule;
    public static MyIconButton buttonStop;
    public static MyIconButton buttonStartNow;

    public static JProgressBar progressTotal;
    public static JProgressBar progressCurrent;

    public static JLabel labelStatus;
    public static JLabel labelStatusDetail;

    public JTextField taskName;
    public static JLabel labelFrom;
    public static JLabel labelTo;

    public static JTextField sourceTextField;
    public static JTextField targetTextField;

    public JButton sourceButton;
    public JButton targetButton;

    private JComboBox productCombox;
    private JComboBox sourceVersionCombox;
    private JComboBox targetVersionCombox;

    private DefaultComboBoxModel producModel;
    private DefaultComboBoxModel sourceModel;
    private DefaultComboBoxModel targetModel;

    public JTextArea logArea;

    private String targetPath=ConstantsUI.CURRENT_DIR;

    //总进度
    private JLabel labelTotal;

    public static boolean isRunning = false;

    /**
     * 构造
     */
    public StatusPanel() {
        super(true);
        initialize();
        addComponent();
        setContent();
        addListener();
    }

    /**
     * 初始化
     */
    private void initialize() {
        this.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        this.setLayout(new GridBagLayout());
    }

    /**
     * 添加组件
     */
    private void addComponent() {
        this.add(getUpPanel(),new GBC(0,0).setAnchor(GBC.WEST).setInsets(25));
        this.add(getCenterPanel(),new GBC(0,1).setWeight(100,50).setInsets(10,25,0,0).setAnchor(GBC.WEST));
        this.add(getStartPanel(),new GBC(0,2).setWeight(100,20).setInsets(20,25,10,0).setAnchor(GBC.WEST));
        this.add(getDownPanel(),new GBC(0,3).setWeight(100,60).setInsets(0,25,10,10).setFill(GBC.BOTH));
    }

    /**
     * 上部面板
     *
     * @return
     */
    private JPanel getUpPanel() {
        JPanel panelUp = new JPanel();

        panelUp.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelUp.setLayout(new GridBagLayout());

        JLabel labelTitle = new JLabel("ATCA2NFV");
        labelTitle.setFont(ConstantsUI.FONT_TITLE);
        labelTitle.setForeground(ConstantsUI.TOOL_BAR_BACK_COLOR);

        labelStatus = new JLabel("当前状态");
        labelStatusDetail = new JLabel("等待开始");
        labelStatus.setFont(ConstantsUI.FONT_NORMAL_BORD);
        labelStatusDetail.setFont(ConstantsUI.FONT_NORMAL);

        panelUp.add(labelTitle,new GBC(0,0).setAnchor(GBC.WEST));
        panelUp.add(labelStatus,new GBC(0,1).setAnchor(GBC.WEST).setInsets(10,0,10,0));
        panelUp.add(labelStatusDetail,new GBC(0,2).setAnchor(GBC.WEST));
        return panelUp;
    }

    /**
     * 中部面板
     *
     * @return
     */
    private JPanel getCenterPanel() {

        JPanel panelCenter = new JPanel();
        panelCenter.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelCenter.setLayout(new GridBagLayout());

        JLabel taskLabel = new JLabel("局点名称");
        taskLabel.setFont(ConstantsUI.FONT_NORMAL);
        taskName = new JTextField();

        //产品、版本Grid
        JLabel productLabel = new JLabel("产品");
        productLabel.setFont(ConstantsUI.FONT_NORMAL);
        JLabel sourceVersionLable = new JLabel("源版本");
        sourceVersionLable.setFont(ConstantsUI.FONT_NORMAL);
        JLabel targetVersionLabel = new JLabel("目标版本");
        targetVersionLabel.setFont(ConstantsUI.FONT_NORMAL);

        productCombox = new JComboBox();
        productCombox.addItem("MSX");
        productCombox.addItem("CSX");
        sourceVersionCombox = new JComboBox();
        sourceVersionCombox.addItem("V200R009C20");
        targetVersionCombox = new JComboBox();
        targetVersionCombox.addItem("V500R012C20");


        //源文件
        labelFrom = new JLabel("源文件");
        labelFrom.setFont(ConstantsUI.FONT_NORMAL);
        sourceTextField = new JTextField();
        sourceButton = new MyIconButton(ConstantsUI.ICON_OPEN,ConstantsUI.ICON_OPENENABLE,ConstantsUI.ICON_OPEN,"");

        //目标文件
        labelTo = new JLabel("结果保存路径");
        labelTo.setFont(ConstantsUI.FONT_NORMAL);
        targetTextField = new JTextField();
        targetButton = new MyIconButton(ConstantsUI.ICON_OPEN,ConstantsUI.ICON_OPENENABLE,ConstantsUI.ICON_OPEN,"");

        //布局

        panelCenter.add(taskLabel,new GBC(0,0).setAnchor(GBC.WEST));
        panelCenter.add(taskName,new GBC(1,0,5,1).setFill(GBC.HORIZONTAL).setInsets(10));

        panelCenter.add(productLabel,new GBC(0,1).setAnchor(GBC.WEST));
        panelCenter.add(productCombox,new GBC(1,1).setInsets(10));
        panelCenter.add(sourceVersionLable,new GBC(2,1));
        panelCenter.add(sourceVersionCombox,new GBC(3,1).setInsets(10));
        panelCenter.add(targetVersionLabel,new GBC(4,1));
        panelCenter.add(targetVersionCombox,new GBC(5,1).setInsets(10));

        panelCenter.add(labelFrom,new GBC(0,2).setAnchor(GBC.WEST));
        panelCenter.add(sourceTextField,new GBC(1,2,5,1).setFill(GBC.HORIZONTAL).setInsets(10));
        panelCenter.add(sourceButton,new GBC(12,2,1,1));

        panelCenter.add(labelTo,new GBC(0,3));
        panelCenter.add(targetTextField,new GBC(1,3,5,1).setFill(GBC.HORIZONTAL).setInsets(10));
        panelCenter.add(targetButton,new GBC(12,3,1,1));

//        panelCenter.add(buttonStartNow,new GBC(0,4).setInsets(30).setAnchor(GBC.EAST));

        return panelCenter;
    }

    private JPanel getStartPanel(){
        JPanel panel=new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        //启动按钮
        buttonStartNow = new MyIconButton(ConstantsUI.ICON_SYNC_NOW, ConstantsUI.ICON_SYNC_NOW_ENABLE,
                ConstantsUI.ICON_SYNC_NOW_DISABLE, "");
        panel.add(buttonStartNow);
        return panel;
    }

    /**
     * 底部面板
     *
     * @return
     */
    private JPanel getDownPanel() {
        JPanel panelDown = new JPanel();
        panelDown.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        panelDown.setLayout(new BoxLayout(panelDown, BoxLayout.Y_AXIS));

        logArea = new JTextArea("转换日志...\n");
        logArea.setForeground(Color.BLACK);
        //启动自动换行
        logArea.setLineWrap(true);
        //换行不断字
        logArea.setWrapStyleWord(true);

        JScrollPane scrollBar = new JScrollPane(logArea);
        scrollBar.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        JPanel progressPanel = new JPanel();
        progressPanel.setLayout(new BoxLayout(progressPanel, BoxLayout.X_AXIS));
        labelTotal = new JLabel("转换进度");
        progressPanel.setBackground(ConstantsUI.MAIN_BACK_COLOR);
        labelTotal.setFont(ConstantsUI.FONT_NORMAL);
        progressTotal = new JProgressBar();

        progressPanel.add(labelTotal);
        progressPanel.add(progressTotal);

        scrollBar.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panelDown.add(progressPanel);
        panelDown.add(scrollBar);
        panelDown.setAlignmentX(Component.LEFT_ALIGNMENT);
        return panelDown;
    }

    /**
     * 设置状态面板组件内容
     */
    public static void setContent() {
        String path = ConstantsUI.CURRENT_DIR;
        targetTextField.setText(path);
    }

    /**
     * 为各组件添加事件监听
     */
    private void addListener() {
        buttonStartNow.addActionListener(e -> {
            if (isRunning == false) {
                buttonStartNow.setEnabled(false);
                labelTotal.setVisible(true);
                progressTotal.setVisible(true);
                StatusPanel.progressTotal.setValue(0);
                labelStatus.setText(PropertyUtil.getProperty("ds.ui.status.manu"));
                ExecuteThread syncThread = new ExecuteThread();
                syncThread.start();
            }
        });

        sourceButton.addActionListener(e ->{
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            FileNameExtensionFilter filter = new FileNameExtensionFilter("TXT FILE","txt","TXT","Txt");
            chooser.setFileFilter(filter);
            int ret = chooser.showOpenDialog(this);
            if (ret == JFileChooser.APPROVE_OPTION){
                sourceTextField.setText(chooser.getSelectedFile().getPath());
            }
        });

        targetButton.addActionListener(e ->{
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int ret = chooser.showOpenDialog(this);
            if (ret == JFileChooser.APPROVE_OPTION){

                targetPath = chooser.getSelectedFile().getPath();
                targetTextField.setText(targetPath+ File.separator+taskName.getText().replace(" ",""));
            }
        });

        taskName.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                targetTextField.setText(targetPath+ File.separator+taskName.getText().replace(" ",""));
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                targetTextField.setText(targetPath+ File.separator+taskName.getText().replace(" ",""));
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                targetTextField.setText(targetPath+ File.separator+taskName.getText());
            }
        });
    }
}

