package UI.mycontainer;

import UI.ConstantsUI;

import javax.swing.*;
import java.awt.*;

public class IComboBox extends JFrame{

    public IComboBox(){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        JLabel label1=new JLabel("主题格式");
        JLabel label2 = new JLabel("消息");
        JLabel label3 = new JLabel("等待开始");
        JTextArea logArea = new JTextArea("转换日志...\n");
        logArea.setForeground(Color.white);
        logArea.setBackground(Color.BLACK);
        //启动自动换行
        logArea.setLineWrap(true);
        //换行不断字
        logArea.setWrapStyleWord(true);

        JScrollPane js = new JScrollPane(logArea);
        js.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        JScrollBar scrollBar = js.getVerticalScrollBar();

        JPanel progressPanel = new JPanel();
        progressPanel.setLayout(new BoxLayout(progressPanel, BoxLayout.X_AXIS));
        JLabel labelTotal = new JLabel("转换进度");
        labelTotal.setFont(ConstantsUI.FONT_NORMAL);
        JProgressBar progressTotal = new JProgressBar();
        progressTotal.setMaximumSize(new Dimension(400, 25));
        panel.add(label1);
        panel.add(label2);
        panel.add(label3);
        panel.add(js);
        panel.setBorder(BorderFactory.createEmptyBorder(10,110,0,0));
        panel.setBorder(BorderFactory.createLineBorder(Color.cyan));
        add(panel);
        setSize(800,600);
        setVisible(true);
    }

    public static void main(String[] args) {
            IComboBox comboBox = new IComboBox();

           }

}
